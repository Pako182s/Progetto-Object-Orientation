package GUI;

import Controller.Controller;

import javax.swing.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class GiudiceGUI {
    private JPanel panel1;
    private JButton esciButton;
    private JButton modificaProblemaButton;
    private JLabel labelDataChiusura;  // Etichetta per mostrare data chiusura
    private JButton votiButton;
    private JButton classificaButton;
    private JButton visualizzaDocumentiButton;
    public JFrame frame;

    private Controller controller;

    public GiudiceGUI(JFrame frameChiamante, Controller controller, String nomeUtente) {
        this.controller = controller;

        frame = new JFrame("Area Giudice - " + nomeUtente);
        frame.setContentPane(panel1);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.pack();


        esciButton.addActionListener(e -> {
            frameChiamante.setVisible(true);
            frame.dispose();
        });

        //mostra la data di chiusura iscrizioni accanto al textField
        Date dataChiusura = controller.getHackaton().getFineIscrizioni();
        String dataTesto;
        //controlla se la data è disponibile, così da formattarla e mostrarla
        if (dataChiusura != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            dataTesto = sdf.format(dataChiusura);
        } else {
            dataTesto = "Data chiusura non impostata";
        }
        labelDataChiusura.setText("Fine modifica: " + dataTesto);

        //controlla se la modifica è permessa in base alla fine delle iscrizioni
        boolean modificaConsentita = (dataChiusura == null || new Date().before(dataChiusura));
        modificaProblemaButton.setEnabled(modificaConsentita);


        modificaProblemaButton.addActionListener(e -> {
            new ModificaProblema(frame, controller);
        });

        votiButton.addActionListener(e -> {
            new Voti(frame, controller); // Assumendo che Voti sia un JFrame
        });

        classificaButton.addActionListener(e -> {
            new ClassificaGUI(frame, controller);
        });

        visualizzaDocumentiButton.addActionListener(e -> {
            new VisualizzaDocGUI(frame, controller);
        });



    }
}