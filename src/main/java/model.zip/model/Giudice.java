package model;

public class Giudice extends UtenteIscritto {

    public void pubblicaDescrizioneProblema() {
        // Implementazione
    }

    public void assegnaVoto(int valore) {

    }

    public void commentoDocumento(String messaggio) {

    }
}
