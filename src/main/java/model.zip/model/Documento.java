package model;

public class Documento {
    private String documento;
    private String commentoGiudice;

    public Documento(String documento, String commentoGiudice) {
        this.documento = documento;
        this.commentoGiudice = commentoGiudice;
    }
}
