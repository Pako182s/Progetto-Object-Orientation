package model;

public class Organizzatore extends UtenteIscritto {

    public void inviaInvitoGiudice(String messaggio) {

    }
}