package model;

public class Voto {
    private int valoreVoto;
}
